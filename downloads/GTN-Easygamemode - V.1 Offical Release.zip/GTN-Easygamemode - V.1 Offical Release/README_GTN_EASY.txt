README - Guess The Number - Easygamemode Version 1 (Publicly Released)

Guess The Number (GTN) and all of its other Gamemodes, featues, aspects, and componets (this includes all artwork created for the game) are a copyright of Asep1582 (asep3192) 

Updates
Every so often Check the Guess The Number Wiki Easy page (or where you downloaded it) for updates. The game can be found on the creators Github (asep3192) if you would like to download there instead.  Recomededation: Once every month or every 3 weeks.

Rules 
No cheating. 
Do not Delete this READ ME text document.
When updated "replace all files" with the new version. You can keep the .dll files as long as they are with the game (in the same location) (.exe).
DO NOT DELETE .dll files or else the game will stop working.
Do not distribute. Unless you are backing up files (file history, or other system back up options).
Do Not Plagiarize





Links:
Creators Github: github.com/asep3192
GTN Wiki Website: dub.sh/GTN-wiki
If you would like to contact the creator you can contact them through Twiter/X at: x.com/asep3192 and then message or DM.
OR through email at: Coming soon


Date Released
Guess The Number - Easy Gamemode Version 1 was released to the public on March 17, 2025 (3/17/25) on the Easypage of the Guess The Number wiki. 

Where to find other gamemodes
The other gamemodes of GTN (Guess The Number) can be found on their own gamemode pages like how Easy gamemode has its own page. When the other gamemodes are released you can download them from their Pages.

Other gamemodes to be released at a later point (in the future).
Guess The Number - Medium Easy Gamemode
Guess The Number - Medium Gamemoded
Guess The Number - Hard Mode 
Guess The Number - Extra Hard Mode (Hardest version of Guess The Number)
